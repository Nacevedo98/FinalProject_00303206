#Nathaniel Acevedo
#Student ID: 00303206
#Final project - Create a calculator object
#Programming for IT - CIS 153
#This project allows the user to create three different calculator objects, each of which with their
#own unique functions. The data outputted from these calculators are stored into a log file which
#can be refernced by the user to view previous history

#the three different calculator classes are imported from the calculatorTypes folder
#os import is used to specify file path
#re import is used for the findall regular expression used when getting data from the history file
from calculatorTypes.calculatorOne import calculatorOne
from calculatorTypes.calculatorTwo import calculatorTwo
from calculatorTypes.calculatorThree import calculatorThree
import os
import re

#history file path
cur_folder = os.path.dirname(os.path.abspath(__file__))
historyFile = os.path.join(cur_folder, 'history.txt')

#creates the history file if it doesn't exist, then opens it
def createFile():

    try:
        open(historyFile)
    except:
        print("Creating new file...")
        open(historyFile, "w")

#function definition for a calculator that uses one value
def calculatorOneFunctions():
    myCalculator = calculatorOne() #calculator object is created

    print("Select an option you would like to perform \n")
    calculatorOneMenu()
    while True: #this is used to loop until a break is reached. Pressing '6' breaks the loop

        calcOption = int(input())
        if calcOption == 0:
            calculatorOneMenu()
            print("Select an option you would like to perform \n")

        elif calcOption == 1:
            print("Find the factors of your number! \n")
            num = int(input("Enter a number: "))
            result = myCalculator.factors(num)
            print("Result:",result," \n")
            num = str(num)
            result = str(result)
            calcDataToFile("One","Factors",num,result)
            calculatorMiniMenu(1)

        elif calcOption == 2:
            print("Find the square root of your number! \n")
            num = int(input("Enter a number: "))
            result = myCalculator.squareRoot(num)
            print("Result:",result," \n")
            num = str(num)
            result = str(result)
            calcDataToFile("One","Square Root",num,result)
            calculatorMiniMenu(1)

        elif calcOption == 3:
            print("Find the factorial of your number! \n")
            num = int(input("Enter a number: "))
            result = myCalculator.factorial(num)
            print("Result:",result," \n")
            num = str(num)
            result = str(result)
            calcDataToFile("One","Factorial",num,result)
            calculatorMiniMenu(1)

        elif calcOption == 4:
            print("Find the log of your number with base 10! \n")
            num = int(input("Enter a number: "))
            result = myCalculator.logBase10(num)
            print("Result:",result," \n")
            num = str(num)
            result = str(result)
            calcDataToFile("One","Log w/ base 10",num,result)
            calculatorMiniMenu(1)

        elif calcOption == 5:
            print("Finds the sin, cos, and tan of your number! \n")
            num = int(input("Enter a number: "))
            result = myCalculator.sinCosTan(num)
            print("Result:",result," \n")
            num = str(num)
            result = str(result)
            calcDataToFile("One","Sin/Cos/Tan",num,result)
            calculatorMiniMenu(1)

        elif calcOption == 6:
            home()
            break

        elif calcOption == 7:
            print("See you next time!")
            break

        else:
            calculatorMiniMenu(1)

#function definition for a calculator that uses two values
def calculatorTwoFunctions():
    myCalculator = calculatorTwo() #calculator object is created

    print("Select an option you would like to perform \n")
    calculatorTwoMenu()
    while True: #this is used to loop until a break is reached. Pressing '9' breaks the loop

        calcOption = int(input())
        if calcOption == 0:
            calculatorTwoMenu()
            print("Select an option you would like to perform \n")

        elif calcOption == 1:
            print("Add two numbers together! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.sum(num1,num2)
            print("Result:",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Addition",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 2:
            print("Subtract two numbers by each other! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.difference(num1,num2)
            print("Result:",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Subtraction",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 3:
            print("Multiply two numbers by each other! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.product(num1,num2)
            print("Result:",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Multiplication",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 4:
            print("Divide two numbers by each other! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.quotient(num1,num2)
            print("Result:",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Division",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 5:
            print("Divide two numbers by each other and get the remainder! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.remainder(num1,num2)
            print("Result:",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Get Remainder",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 6:
            print("Raise a number by the power of the other! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number(must be non-negative): "))
            while num2 < 0:
                num2 = int(input("Value cannot be less than 0) "))
            result = myCalculator.exponent(num1,num2)
            print("Result: ",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Exponent",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 7:
            print("Find the average between two numbers! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            result = myCalculator.average(num1,num2)
            print("Result: ",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Average",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 8:
            print("Find the log of number Y with base X! \n")
            num1 = int(input("First number (log base): "))
            num2 = int(input("Second number: "))
            result = myCalculator.logBaseX(num1,num2)
            print("Result: ",result," \n")
            values = [num1,num2]
            values = str(values)
            result = str(result)
            calcDataToFile("Two","Log with base X",values,result)
            calculatorMiniMenu(2)

        elif calcOption == 9:
            home()
            break

        elif calcOption == 10:
            print("See you next time!")
            break

        else:
            calculatorMiniMenu(2)

#function definition for a calculator that uses three values
def calculatorThreeFunctions():
    myCalculator = calculatorThree() #calculator object is created

    print("Select an option you would like to perform \n")
    calculatorThreeMenu()
    while True: #this is used to loop until a break is reached. Pressing '6' breaks the loop

        calcOption = int(input())
        if calcOption == 0:
            calculatorThreeMenu()
            print("Select an option you would like to perform \n")

        elif calcOption == 1:
            print("Sort three numbers from smallest to largest! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            num3 = int(input("Third number: "))
            result = myCalculator.sortBySmallest(num1,num2,num3)
            print("Result: ",result," \n")
            values = [num1,num2,num3]
            values = str(values)
            result = str(result)
            calcDataToFile("Three","Sort by smallest",values,result)
            calculatorMiniMenu(1)

        elif calcOption == 2:
            print("Sort three numbers from largest to smallest! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            num3 = int(input("Third number: "))
            result = myCalculator.sortByLargest(num1,num2,num3)
            print("Result: ",result," \n")
            values = [num1,num2,num3]
            values = str(values)
            result = str(result)
            calcDataToFile("Three","Sort by largest",values,result)
            calculatorMiniMenu(1)

        elif calcOption == 3:
            print("Enter 3 numbers and return the smallest! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            num3 = int(input("Third number: "))
            result = myCalculator.getSmallest(num1,num2,num3)
            print("Result: ",result," \n")
            values = [num1,num2,num3]
            values = str(values)
            result = str(result)
            calcDataToFile("Three","Get smallest",values,result)
            calculatorMiniMenu(1)

        elif calcOption == 4:
            print("Enter 3 numbers and return the largest! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            num3 = int(input("Third number: "))
            result = myCalculator.getLargest(num1,num2,num3)
            print("Result: ",result," \n")
            values = [num1,num2,num3]
            values = str(values)
            result = str(result)
            calcDataToFile("Three","Get largest",values,result)
            calculatorMiniMenu(1)

        elif calcOption == 5:
            print("Find the average between 3 numbers! \n")
            num1 = int(input("First number: "))
            num2 = int(input("Second number: "))
            num3 = int(input("Third number: "))
            result = myCalculator.average(num1,num2,num3)
            print("Result: ",result," \n")
            values = [num1,num2,num3]
            values = str(values)
            result = str(result)
            calcDataToFile("Three","Average",values,result)
            calculatorMiniMenu(1)

        elif calcOption == 6:
            home()
            break

        elif calcOption == 7:
            print("See you next time!")
            break

        else:
            calculatorMiniMenu(1)

#menu functions are called after a calculator object is created and whenever the user presses '0'
def calculatorOneMenu():
    print("[0]: Menu\n")
    print("[1]: Factors \n")
    print("[2]: Square Root \n")
    print("[3]: Factorial \n")
    print("[4]: Log of X with base10 \n")
    print("[5]: Find sine, cosine, and tangent \n")
    print("[6]: Home \n")
    print("[7]: Exit \n")

def calculatorTwoMenu():
    print("[0]: Menu\n")
    print("[1]: Add \n")
    print("[2]: Subtract \n")
    print("[3]: Multiply \n")
    print("[4]: Divide \n")
    print("[5]: Get remainder \n")
    print("[6]: Raise X to the power of Y \n")
    print("[7]: Average \n")
    print("[8]: Log of Y with base X\n")
    print("[9]: Home \n")
    print("[10]: Exit\n")

def calculatorThreeMenu():
    print("[0]: Menu\n")
    print("[1]: Sort from smallest to largest \n")
    print("[2]: Sort from largest to smallest \n")
    print("[3]: Get smallest \n")
    print("[4]: Get largest \n")
    print("[5]: Find average \n")
    print("[6]: Home\n")
    print("[7]: Exit \n")

def historyMenu():
    print("Choose which history information to view \n")
    print("[1]: Calculator types \n")
    print("[2]: Calculator functions \n")
    print("[3]: User's input values \n")
    print("[4]: Outputs \n")
    print("[5]: All history \n")

def calculatorMiniMenu(num):
    print("Select an option you would like to perform \n")
    print("[0]: Menu\n")
    if num == 1:
        print("[6]: Home\n")
        print("[7]: Exit\n")
    elif num == 2:
        print("[9]: Home\n")
        print("[10]: Exit\n")

#writes to the history file. Information contains calculator type, function used,
#inputs entered, and output recieved.
def calcDataToFile(calcType,calcFunc,values,output):

    with open (historyFile,'a') as fhand:
        fhand.write("CALCULATOR TYPE: ")
        fhand.write(calcType)
        fhand.write(" | FUNCTION: ")
        fhand.write(calcFunc)
        fhand.write(" | INPUT(S): ")
        fhand.write(values)
        fhand.write(" | OUTPUT: ")
        fhand.write(output)
        fhand.write("\n")

#this function prints the default prompt for the user and allows them to choose which calculator
#they want to use or view history
def home():
    print("Welcome! Select which calculator you would like to use!\n")
    print("[1]: calculator using 1 value \n")
    print("[2]: calculator using 2 values \n")
    print("[3]: calculator using 3 values \n")
    print("[4]: view calculator history \n")
    print("[5]: exit \n")

    while True: #this is used to loop until a break is reached. Every valid number breaks the loop (1-5)

        calcType = int(input())

        if calcType == 1:
            print("SELECTED: calculator using 1 value! \n")
            calculatorOneFunctions() #calls the function that creates the calculatorOne object
            break

        elif calcType == 2:
            print("SELECTED: calculator using 2 values! \n")
            calculatorTwoFunctions() #calls the function that creates the calculatorTwo object
            break

        elif calcType == 3:
            print("SELECTED: calculator using 3 values! \n")
            calculatorThreeFunctions() #calls the function that creates the calculatorThree object
            break

        elif calcType == 4: #views the log data information
            if os.stat(historyFile).st_size == 0:
                print("File is empty! No history to report. \n")
                home()

            else:
                print("SELECTED: viewing calculator history! \n")
                historyMenu()

                while True:
                    #regular expressions are used to find specific information in the history file
                    historyChoice = int(input())

                    if historyChoice == 1:
                        with open (historyFile, 'r') as fhand:
                            for line in fhand:
                                data = re.findall("(CALCULATOR TYPE: .+?) \|",line)
                                data = str(data)
                                print(data)

                        break


                    elif historyChoice == 2:
                        with open (historyFile, 'r') as fhand:
                            for line in fhand:
                                data = re.findall("(FUNCTION: .+?) \|",line)
                                data = str(data)
                                print(data)
                        break

                    elif historyChoice == 3:
                        with open (historyFile, 'r') as fhand:
                            for line in fhand:
                                data = re.findall("(INPUT\(S\): .+?) \|",line)
                                data = str(data)
                                print(data)
                        break

                    elif historyChoice == 4:
                        with open (historyFile, 'r') as fhand:
                            for line in fhand:
                                data = re.findall("OUTPUT: .+",line)
                                data = str(data)
                                print(data)
                        break

                    elif historyChoice == 5:
                        with open (historyFile, 'r') as fhand:
                            for line in fhand:
                                print(line)
                        break

                    else:
                        historyMenu()

            break

        elif calcType == 5:
            print("See you next time!")
            break

        else:
            print("Please select 1,2,3,4 or 5\n")

#default prompt starts here
createFile()
home()
