import math

class calculatorTwo:

    def addition(self,num1,num2): #adds two numbers together and returns the sum
        sum = num1 + num2
        return sum

    def subtraction(self,num1,num2): #subtracts the first number by the second number and returns the difference
        dif = num1 - num2
        return dif

    def product(self,num1,num2): #multiplies two numbers by each other and returns the product
        pro = num1 * num2
        return pro

    def quotient(self,num1,num2): #divides the first number by the second number and returns the quotient
        quo = num1/num2
        quo = round(quo,2)
        return quo

    def remainder(self,num1,num2): #divides the first number by the second number and uses modulo to return the remainder
        rem = num1 % num2
        return rem

    def exponent(self,num1,num2): #raises the first number by the power of second number and returns the value
        exp = num1 ** num2
        return exp

    def average(self,num1,num2): #adds both numbers together, then divides by 2 to find and return the average
        total = num1 + num2
        avg = total / 2
        avg = round(avg,2)
        return avg

    def logBaseX(self,num1,num2): #using log base number 1; finds and returns the value of log number 2
        logData = math.log(num1,num2)
        logData = round(logData,2)
        return logData
