import math

class calculatorOne:

    def factors(self,num): #returns a list of numbers containing the factors of the number inputed
        factors = []
        numMax = num + 1
        for i in range(1,numMax):
            if num % i == 0:
                factors.append(i)
        return factors

    def squareRoot(self,num): #returns the square root of the number inputed
        root = math.sqrt(num)
        root = round(root,2)
        return root

    def factorial(self,num): #returns the factorial of the number inputed
        fact = math.factorial(num)
        return fact

    def logBase10(self,num): #returns log base 10 of the number inputed
        logData = math.log10(num)
        logData = round(logData,2)
        return logData

    def sinCosTan(self,num): #returns a dictionary containing the sine, cosine, and tangenet values of the number inputed
        trig = dict()
        sin = math.sin(math.pi/num)
        cos = math.cos(math.pi/num)
        sin = round(sin,2)
        cos = round(cos,2)

        tan = math.tan(math.pi/num)
        tan = round(tan,2)

        trig['sine'] = sin
        trig['cosine'] = cos
        trig['tangent'] = tan

        return trig
