import math

class calculatorThree:

    def calculatorThree(self):
        print("CalculatorThree has been constructed \n")

    def sortBySmallest(self,num1,num2,num3): #creates a list of three numbers and returns a sorted list of those numbers (by smallest)
        list = [num1,num2,num3]
        list.sort()
        return list

    def sortByLargest(self,num1,num2,num3): #creates a list of three numbers and returns a sorted list of those numbers (by largest)
        list = [num1,num2,num3]
        list.sort(reverse=True)
        return list

    def getSmallest(self,num1,num2,num3): #creates a list of three numbers and returns the smallest value in that list
        list = [num1,num2,num3]
        list.sort()
        return list[0]

    def getLargest(self,num1,num2,num3): #creates a list of three numbers and returns the largest value in that list
        list = [num1,num2,num3]
        list.sort(reverse=True)
        return list[0]

    def average(self,num1,num2,num3): #adds all three numbers together, then divides by 3 to find and return the average
        sum = num1 + num2 + num3
        avg = sum / 3
        return avg
